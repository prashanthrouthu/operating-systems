//CAS
#include<iostream>
#include<thread>
#include<chrono>
#include<atomic>
#include<random>
#include<fstream>
#include<vector>
#include<unistd.h>
#include<sstream>
#include<time.h>
#include<ctime>
#include<ratio>
#include<sys/time.h>
#define scale 1000
void testCs(int i);
typedef long long int lli;
lli n,k;
using namespace std;
ofstream output("CAS ME Output");
default_random_engine generator(time(NULL));
exponential_distribution<double> *dis1;
exponential_distribution<double> *dis2;
bool *ready;
atomic<bool>check;
time_t tym;
double avg_wait=0;
double max_wait=0;
vector<lli> getSysTime()
{
	time(&tym);
	lli t2;
	struct timeval tv;
	gettimeofday(&tv,NULL);
	t2=(tv.tv_usec/1000);
	struct tm* time;
	time = localtime(&tym);
	vector<lli> vect;
	vect.push_back(time->tm_hour);
	vect.push_back(time->tm_min);
	vect.push_back(time->tm_sec);
	vect.push_back(t2);
	return vect;
}
double curr_waiting(vector<lli> vec1, vector<lli> vec2)
{
	vector<lli> aux;
	aux.push_back(vec1[0]-vec2[0]);
	aux.push_back(vec1[1]-vec2[1]);
	aux.push_back(vec1[2]-vec2[2]);
	aux.push_back(vec1[3]-vec2[3]);
	double a;
	a=3600*aux[0]+60*aux[1]+aux[2]+double(aux[3])/1000;
	return a;
}
double max_waiting(double a, double b)
{
	if(a>b)
	{
		return a;
	}
	else
	{
		return b;
	}
}
int main()
{
	double l1,l2;
	ifstream input("inp-params.txt");
	input>>n>>k>>l1>>l2;
	dis1= new exponential_distribution<double>(1/l1);
	dis2=new exponential_distribution<double>(1/l2);
	ready = new bool[n];
	vector<thread> threadvect;
	for(int i=0;i<n;i++)
	{
		threadvect.push_back(thread(testCs,i));
	}
	for(int i=0;i<n;i++)
	{
		threadvect[i].join();
	}
	delete dis1;
	delete dis2;
	delete[] ready;
	cout<< "worst case waiting time in seconds: "<<max_wait<< endl;
	cout<<"avg.waiting time in seconds: "<< avg_wait/(n*k) << endl;
}
void testCs(int id)
{
	for(auto i=0;i<k;i++)
	{
		vector<lli> vect=getSysTime();
		ready[id]=true;
		bool key=true;
		bool flag=false;
		while(ready[id] && key)
		{
			if(atomic_compare_exchange_strong(&check,&flag,true))
			{
				key=false;
			}
			else 
			{
				flag=false;
			}
		}	
		auto vect2= getSysTime();
		output<<i+1<<"th CS Request at "<<vect[0]<<":"<<vect[1]<<":"<<vect[2]<<":"<<vect[3] << " by thread" << id+1<<endl;
		output<<i+1<<"th CS Entry at "<<vect2[0]<<":"<<vect2[1]<<":"<<vect2[2]<< ":"<<vect2[3]<< " by thread" << id+1<<endl;
		avg_wait+= curr_waiting(vect2,vect);
		max_wait= max_waiting(max_wait, curr_waiting(vect2,vect));
		usleep((*dis1)(generator)*scale);
		auto vect3= getSysTime();
		output<<i+1<<"th CS Exit at "<<vect3[0]<<":"<<vect3[1]<<":"<<vect3[2]<<":"<<vect3[3] << " by thread" << id+1<<endl;
		check=false;
		usleep((*dis2)(generator)*scale);	
	}
}
