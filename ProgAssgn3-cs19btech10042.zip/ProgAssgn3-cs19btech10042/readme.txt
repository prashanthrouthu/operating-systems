for compilation open terminal and change the directory to the one which contains the assignment file
enter in terminal for compiling cas_bounded;
 g++ SrcAssgn3-cas-bounded-cs19btech11042.cpp -pthread
for running enter
./a.out
and for compiling cas enter
g++ SrcAssgn3-cas-cs19btech11042.cpp -pthread
for running enter
./a.out
For tas enter the following in terminal
g++ SrcAssgn3-tas-cs19btech11042.cpp -pthread
for running it enter
./a.out



