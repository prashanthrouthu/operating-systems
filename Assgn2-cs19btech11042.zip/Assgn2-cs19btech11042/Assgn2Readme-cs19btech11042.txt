open the terminal
change the directory to the directory containing the source code.
for compiling RMS scheduling enter 
g++ Assgn2-RMScs19btech11042.cpp
for executing enter 
./a.out 
then enter the input values
and for EDF schdeuling enter the following to compile
g++ Assgn2-EDFcs19btech11042.cpp
for executing enter
./a.out
then enter the input values
