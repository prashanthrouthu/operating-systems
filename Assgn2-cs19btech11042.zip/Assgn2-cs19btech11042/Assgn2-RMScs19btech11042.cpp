/*
  ratemonotonic scheduling;
*/
#include<iostream>
#include<queue>     //for priority queue data str
#include<fstream> //for ofstream class which ouputs to a file
using namespace std;
class process{
	public:
	int pid;
	int rem_time;
	int period;
	int join_time;
	process(int, int, int ,int);   //constructor
};
process::process(int a,int b,int c,int d)
{
	pid=a;
	rem_time=b;
	period=c;
	join_time=d;
}
bool operator<(const process& p, const process &q)  //operator overloading so that it can be put to priority queue
{
	if(p.period == q.period)
	{
		return p.pid > q.pid;
	}
	else
	{
		return p.period > q.period; //priority is given to least period process
	}
}
class event{
	public:
	int pid;
	int event_time;
	event(int,int);
};
event::event(int a,int b)
{
	pid=a;
	event_time=b;
}
bool operator<(const event& p, const event& q)  //operator overloading to keep it in queue
{
	if(p.event_time==q.event_time)
	{
		return p.pid > q.pid;
	}
	else
	{
		return p.event_time > q.event_time; //lesser the event time on clock more the priority
	}
}
int main()
{
	int n;
	cin>>n;
	int exec_time[n];
	int period[n];
	int remain_turns[n];            //total turns a process i undergoes is remaing_turns[i-1]
	int waiting_time[n];
	int deadmiss=0;  				//initialising deadline missed processes
	priority_queue<process> p1; 	//readyqueue of processes
	priority_queue<event> e1; 		//event time line
	int index;						//id of process
	ofstream output("RM-Log.txt");
	ofstream outputq("RM-Stats.txt");
	for(int i=0; i<n; i++) 			//creatig the ready queue for frst time
	{
		cin>> index >> exec_time[i] >> period[i] >> remain_turns[i];
		p1.push(process(index,exec_time[i],period[i],0));
		waiting_time[i]=0;
		output<< "Process P"<<index<<" : processing time= "<<exec_time[i]<<" period="<<period[i]<<": joined the system at t=0"<<endl;
	}
	for(int i=1; i<=n; i++)			 //creating event timeline; not including the initial readyqueue
	{
		for(int j=1;j < remain_turns[i-1]; j++)
		{
			e1.push(event(i,j*period[i-1]));
		}
	}
	
	int current_time=0;
	while(!e1.empty() || !p1.empty())		//until no process is present in readyqueue and no event is left out
	{
		if(!p1.empty() && !e1.empty())      //both event timeline and readyqueue are not empty
		{
			process aux=p1.top();
			event temp=e1.top();
			if(current_time + aux.rem_time > aux.period + aux.join_time)	//does the process miss deadline?
			{
				output<< "Process P"<<aux.pid<<" misses its deadline\n";
				deadmiss=deadmiss+1;
				waiting_time[aux.pid-1] += aux.period;
				p1.pop();
			}
			else if(current_time + aux.rem_time <= temp.event_time)	//the pocessing happens between the events in the event time line..so it runs smooth
			{
				if(aux.rem_time == exec_time[aux.pid-1])			//is the process executing frst time in this cycle
				{
					output<< "Process P"<<aux.pid<<" starts execution at time "<<current_time << endl;
					current_time = current_time + aux.rem_time;
					output<< "Process P"<<aux.pid<<" finishes execution at time "<<current_time << endl;  //in btwn events execution of process is smooth
					waiting_time[aux.pid-1] +=(current_time-aux.join_time)-exec_time[aux.pid-1];
					p1.pop();
					while(!e1.empty() && (temp.event_time == current_time)) //all the events in the eventline of current time should be converted to repected process adds in ready queue
			        {
						p1.push(process(temp.pid,exec_time[temp.pid-1],period[temp.pid-1],current_time));
						output<< "Process P"<<temp.pid<<": processing time="<<exec_time[temp.pid-1]<<": period="<<period[temp.pid-1]<<": joined the system at t="<<current_time<<endl;
						e1.pop();
						temp=e1.top();
					}
				}
				else
				{
					output<< "Process P"<<aux.pid<<" resumes its execution  at time "<<current_time << endl;
					current_time = current_time + aux.rem_time;
					output<< "Process P"<<aux.pid<<" finishes execution at time "<<current_time << endl;
					waiting_time[aux.pid-1] +=(current_time-aux.join_time)-exec_time[aux.pid-1];
					p1.pop();	
					while(!e1.empty() && (temp.event_time == current_time))
			        {
						p1.push(process(temp.pid,exec_time[temp.pid-1],period[temp.pid-1],current_time));
						output<< "Process P"<<temp.pid<<": processing time="<<exec_time[temp.pid-1]<<": period="<<period[temp.pid-1]<<": joined the system at t="<<current_time<<endl;
						e1.pop();
						temp=e1.top();
					}
				}
			}
			else if(current_time + aux.rem_time > temp.event_time)	//there is an interupt in the event timeline in midst of proceesing
			{
				p1.pop();
				if(aux.rem_time == exec_time[aux.pid-1])
				{
					output<< "Process P"<<aux.pid<<" starts execution at time "<<current_time << endl;
				}
				else
				{
					output<< "Process P"<<aux.pid<<" resumes its execution  at time "<<current_time << endl;
				}
				aux.rem_time = aux.rem_time - (temp.event_time - current_time);
				current_time = temp.event_time;
				while(!e1.empty() && (temp.event_time == current_time))
			    {
				    p1.push(process(temp.pid,exec_time[temp.pid-1],period[temp.pid-1],current_time));
					output<< "Process P"<<temp.pid<<": processing time="<<exec_time[temp.pid-1]<<": period="<<period[temp.pid-1]<<": joined the system at t="<<current_time<<endl;
					e1.pop();
					temp=e1.top();
				}
				output<< " Event interupts here and Sheduling decision is made " << endl;
				if(aux.period > p1.top().period) //if the scheduler decides to suspend this process for newly arrived one
				{
					p1.push(process(aux.pid,aux.rem_time,aux.period,aux.join_time));
					output<<"process P"<<aux.pid<< " got preemptied by p"<<p1.top().pid<< " at time" << current_time<<endl;
				}
				else
				{
					p1.push(process(aux.pid,aux.rem_time,aux.period,aux.join_time));
				}
			}	
		}
		else if(!p1.empty()) //if event line is empty but not ready queue then all the process executions are smooth
		{
			process aux=p1.top();
			if(current_time + aux.rem_time > aux.period + aux.join_time)
			{
				output<< "Process P"<<aux.pid<<" misses its deadline\n";
				deadmiss=deadmiss+1;
				waiting_time[aux.pid-1] += aux.period;
				p1.pop();
			}
			else   //if ready que is empty but event timeline is not empty
			{
				output<< "Process P"<<aux.pid<<" starts execution at time "<<current_time << endl;
				current_time = current_time + aux.rem_time;
				output<< "Process P"<<aux.pid<<" finishes execution at time "<<current_time << endl;
				waiting_time[aux.pid-1] +=(current_time-aux.join_time)-exec_time[aux.pid-1];
				p1.pop();
			}
		}	
		else
		{
			event temp=e1.top();
			output<< "CPU is idle from "<<current_time << " to "<< temp.event_time << endl;
			current_time = temp.event_time;
			while(!e1.empty() && (temp.event_time == current_time))
			{
				p1.push(process(temp.pid,exec_time[temp.pid-1],period[temp.pid-1],current_time));
				output<< "Process P"<<temp.pid<<": processing time="<<exec_time[temp.pid-1]<<": period="<<period[temp.pid-1]<<": joined the system at t="<<current_time<<endl;
				e1.pop();
				temp=e1.top();
			}
		}
	}
	int k=0;
	for(int i=0;i<n;i++)
	{
		k=k+remain_turns[i];
	}
	double avg_wait_time=0;
	for(int i=0;i<n;i++)
	{
		avg_wait_time += waiting_time[i];
	}
	avg_wait_time=avg_wait_time/k ;
	outputq<< "Number of processes that came into the system: "<<k <<endl;
	outputq<< "Number of processes that successfully completed: "<< k-deadmiss<<endl;
	outputq<<"Number of processes that missed their deadline: "<< deadmiss<<endl;
	outputq<< "Avg waiting time per process: "<<avg_wait_time<<endl;
}
	
			
		


	  
